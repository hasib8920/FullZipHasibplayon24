-- Database
CREATE DATABASE hasib_Playon24Db;
GO
USE hasib_Playon24Db;
GO

-- Tables
CREATE TABLE Department (
    DepartmentID INT IDENTITY(1,1) PRIMARY KEY,
    DepartmentName NVARCHAR(100) NOT NULL UNIQUE
);
GO

CREATE TABLE Employee (
    EmployeeID INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL,
    DepartmentID INT NULL,
    JoinDate DATE NOT NULL,
    Salary DECIMAL(18,2) NOT NULL,
    FOREIGN KEY (DepartmentID) REFERENCES Department(DepartmentID)
);
GO

CREATE TABLE Attendance (
    AttendanceID INT IDENTITY(1,1) PRIMARY KEY,
    EmployeeID INT NOT NULL,
    AttendanceDate DATE NOT NULL,
    Status NVARCHAR(10) NOT NULL,
    UNIQUE (EmployeeID, AttendanceDate),
    FOREIGN KEY (EmployeeID) REFERENCES Employee(EmployeeID),
    CHECK (Status IN ('Present','Absent'))
);
GO

-- TVP Type
CREATE TYPE AttendanceTVP AS TABLE
(
    EmployeeID INT NOT NULL,
    AttendanceDate DATE NOT NULL,
    Status NVARCHAR(10) NOT NULL
);
GO

-- Stored Procedures
CREATE PROCEDURE sp_GetEmployees
AS
BEGIN
    SET NOCOUNT ON;
    SELECT e.EmployeeID, e.Name, e.DepartmentID, d.DepartmentName, e.JoinDate, e.Salary
    FROM Employee e
    LEFT JOIN Department d ON e.DepartmentID = d.DepartmentID
    ORDER BY e.EmployeeID;
END;
GO

CREATE PROCEDURE sp_GetEmployeeAttendance
    @StartDate DATE,
    @EndDate DATE
AS
BEGIN
    SET NOCOUNT ON;
    SELECT e.EmployeeID, e.Name, ISNULL(d.DepartmentName, '(No Department)') AS DepartmentName,
           SUM(CASE WHEN a.Status='Present' THEN 1 ELSE 0 END) AS PresentCount,
           SUM(CASE WHEN a.Status='Absent' THEN 1 ELSE 0 END) AS AbsentCount
    FROM Employee e
    LEFT JOIN Department d ON e.DepartmentID = d.DepartmentID
    LEFT JOIN Attendance a ON e.EmployeeID = a.EmployeeID AND a.AttendanceDate BETWEEN @StartDate AND @EndDate
    GROUP BY e.EmployeeID, e.Name, d.DepartmentName
    ORDER BY e.Name;
END;
GO

CREATE PROCEDURE sp_AddEmployee
    @Name NVARCHAR(100),
    @DepartmentID INT = NULL,
    @JoinDate DATE,
    @Salary DECIMAL(18,2),
    @NewEmployeeID INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO Employee (Name, DepartmentID, JoinDate, Salary)
    VALUES (@Name, @DepartmentID, @JoinDate, @Salary);
    SET @NewEmployeeID = CAST(SCOPE_IDENTITY() AS INT);
END;
GO

CREATE PROCEDURE sp_AddAttendance
    @AttendanceRecords AttendanceTVP READONLY
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO Attendance (EmployeeID, AttendanceDate, Status)
    SELECT t.EmployeeID, t.AttendanceDate, t.Status
    FROM @AttendanceRecords t
    WHERE NOT EXISTS (
        SELECT 1 FROM Attendance a 
        WHERE a.EmployeeID = t.EmployeeID AND a.AttendanceDate = t.AttendanceDate
    );
END;
GO

-- Seed Data
INSERT INTO Department (DepartmentName) VALUES ('HR'), ('IT'), ('Finance');
GO

DECLARE @NewId INT;
EXEC sp_AddEmployee @Name='Tareq', @DepartmentID=2, @JoinDate='2024-03-15', @Salary=55000, @NewEmployeeID=@NewId OUTPUT;
GO

DECLARE @AttendanceData AttendanceTVP;
INSERT INTO @AttendanceData (EmployeeID, AttendanceDate, Status) VALUES (1,'2025-09-01','Present'),(2,'2025-09-01','Absent');
EXEC sp_AddAttendance @AttendanceRecords=@AttendanceData;
GO
