import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Employee {
  employeeID?: number;
  name: string;
  departmentID?: number | null;
  departmentName?: string | null;
  joinDate: string;
  salary: number;
}

export interface EmployeeAttendance {
  employeeID: number;
  name: string;
  departmentName: string;
  presentCount: number;
  absentCount: number;
}

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private base = 'https://localhost:7230/api'; 

  constructor(private http: HttpClient) {}

  getEmployees(): Observable<Employee[]> {
    return this.http.get<Employee[]>(`${this.base}/Employees`);
  }

  addEmployee(emp: { name: string; departmentID?: number | null; joinDate: string; salary: number }) {
    return this.http.post(`${this.base}/Employees`, emp);
  }

  getAttendance(start?: string, end?: string): Observable<EmployeeAttendance[]> {
    let params = new HttpParams();
    if (start) params = params.set('start', start);
    if (end) params = params.set('end', end);
    return this.http.get<EmployeeAttendance[]>(`${this.base}/Attendance`, { params });
  }
}
