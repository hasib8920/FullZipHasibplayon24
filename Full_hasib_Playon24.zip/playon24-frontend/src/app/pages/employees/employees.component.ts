import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService, Employee } from '../../services/api.service';

@Component({
  selector: 'app-employees',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './employees.component.html'
})
export class EmployeesComponent implements OnInit {
  employees: Employee[] = [];
  departments = [
    { id: 1, name: 'HR' },
    { id: 2, name: 'IT' },
    { id: 3, name: 'Finance' }
  ];

  newEmp = {
    name: '',
    departmentID: 2,
    joinDate: this.today(),
    salary: null as number | null
  };

  constructor(private api: ApiService) {}

  ngOnInit(): void {
    this.loadEmployees();
  }

  today() {
    return new Date().toISOString().slice(0, 10);
  }

  loadEmployees() {
    this.api.getEmployees().subscribe({
      next: res => this.employees = res,
      error: err => { console.error(err); alert('Failed to load employees (see console)'); }
    });
  }

  addEmployee() {
    if (!this.newEmp.name || !this.newEmp.joinDate || !this.newEmp.salary) {
      return alert('Name, Join Date and Salary required');
    }
    const payload = {
      name: this.newEmp.name,
      departmentID: this.newEmp.departmentID ?? null,
      joinDate: this.newEmp.joinDate,
      salary: Number(this.newEmp.salary)
    };
    this.api.addEmployee(payload).subscribe({
      next: () => {
        this.loadEmployees();
        this.newEmp = { name: '', departmentID: 2, joinDate: this.today(), salary: null };
      },
      error: err => { console.error(err); alert('Add employee failed (see console)'); }
    });
  }
}
