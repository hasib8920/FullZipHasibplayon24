import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService, EmployeeAttendance } from '../../services/api.service';

@Component({
  selector: 'app-attendance',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './attendance.component.html'
})
export class AttendanceComponent implements OnInit {
  attendance: EmployeeAttendance[] = [];
  start = new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().slice(0,10);
  end = new Date().toISOString().slice(0,10);

  constructor(private api: ApiService) {}

  ngOnInit(): void {
    this.load();
  }

  load() {
    this.api.getAttendance(this.start, this.end).subscribe({
      next: res => this.attendance = res,
      error: err => { console.error(err); alert('Failed to load attendance (see console)'); }
    });
  }

  onFilter() {
    this.load();
  }
}
